<?php

// Partie publique

if (!defined("WIKINI_VERSION"))
{
        die ("acc&egrave;s direct interdit");
}

// Code pour l'inclusion des langues
include_once 'tools/login/lang/login_'.$wakkaConfig['lang'].'.inc.php';

?>
