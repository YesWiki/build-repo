<?php

if (!defined("WIKINI_VERSION"))
{
            die ("acc&egrave;s direct interdit");
}

//ajout du style css pour la syndication
echo '	<link rel="stylesheet" href="tools/syndication/presentation/styles/syndication.css" />'."\n";