<?php

if (!defined("WIKINI_VERSION"))
{
            die ("acc&egrave;s direct interdit");
}


echo '	<script src="tools/aceditor/libs/ACeditor.js"></script>'."\n";
	
?>