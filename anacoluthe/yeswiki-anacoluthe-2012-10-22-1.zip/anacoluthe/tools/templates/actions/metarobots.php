<?php
if (!defined("WIKINI_VERSION"))
{
        die ("acc&egrave;s direct interdit");
}
if ($this->GetMethod() != 'show')  echo "<meta name=\"robots\" content=\"noindex, nofollow\"/>";
?>