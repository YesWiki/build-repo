<?php
	if (!defined("WIKINI_VERSION"))
	{
	        die ("acc&egrave;s direct interdit");
	}

	$this->tag = $oldpage;
	$this->page = $this->LoadPage($oldpage);
?>