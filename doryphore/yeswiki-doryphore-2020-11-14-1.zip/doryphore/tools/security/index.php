<?php
// index.php
// Administration de l'extension : initialisations (tables, fichier de configuration) , information etc. : toutes
// opérations réservées à l'administrateur technique de YesWiki.

// Vérification de sécurité
if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}
