<?php
// index.php
// Administration de l'extension : initialisations (tables, fichier de configuration) , information etc. : toutes
// operations reservees a l'administrateur technique de Wikini.

// Verification de securite
if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}
