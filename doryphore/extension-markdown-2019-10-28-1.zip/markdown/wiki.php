<?php

$wakkaConfig['use_md'] = isset($wakkaConfig['use_md']) ? $wakkaConfig['use_md'] : true;
