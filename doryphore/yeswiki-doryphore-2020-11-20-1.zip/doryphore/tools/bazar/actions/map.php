<?php

/**
 *  Programme gerant les fiches bazar depuis une interface de type geographique.
 **/

// pour retro-compatibilité
$this->setParameter('template', 'map');
include(__DIR__.'/bazarliste.php');
