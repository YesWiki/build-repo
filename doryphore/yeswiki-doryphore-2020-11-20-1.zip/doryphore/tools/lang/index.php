<?php
// index.php

if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}
