<?php
namespace AutoUpdate;

/**
 * Classe Controller
 *
 * gère les entrées ($_POST et $get)
 * @package AutoUpload
 * @author  Florestan Bredow <florestan.bredow@supagro.fr>
 * @version 0.0.1 (Git: $Id$)
 * @copyright 2015 Florestan Bredow
 */
class Controller
{
    private $autoUpdate;
    private $messages;
    private $wiki;

    public function __construct($autoUpdate, $messages, $wiki)
    {
        $this->autoUpdate = $autoUpdate;
        $this->messages = $messages;
        $this->wiki = $wiki;
    }

    /*	Parameter $requestedVersion contains the name of the YesWiki version
        requested by version parameter of {{update}} action
        if empty, no specifc version is requested
    */
    public function run($get, $requestedVersion='')
    {
        if (!isset($get['autoupdate'])) {
            $get['autoupdate'] = "default";
        }

        if (!$this->autoUpdate->initRepository($requestedVersion)) {
            return $this->wiki->render("@autoupdate/views/norepo.twig", []);
        }

        if (isset($get['upgrade'])
            and $this->autoUpdate->isAdmin()
            ) {
            $this->upgrade($get['upgrade']);
            return $this->wiki->render("@autoupdate/views/update.twig", [
                'messages' => $this->messages,
                'baseUrl' => $this->autoUpdate->baseUrl(),
            ]);
        }

        if (isset($get['delete'])
            and $this->autoUpdate->isAdmin()
            ) {
            $this->delete($get['delete']);
            return $this->wiki->render("@autoupdate/views/update.twig", [
                'messages' => $this->messages,
                'baseUrl' => $this->autoUpdate->baseUrl(),
            ]);
        }

        return $this->wiki->render("@autoupdate/views/status.twig", [
            'baseUrl' => $this->autoUpdate->baseUrl(),
            'isAdmin' => $this->autoUpdate->isAdmin(),
            'core' => $this->autoUpdate->repository->getCorePackage(),
            'themes' => $this->autoUpdate->repository->getThemesPackages(),
            'tools' => $this->autoUpdate->repository->getToolsPackages(),
            'showCore' => true,
            'showThemes' => true,
            'showTools' => true
        ]);
    }

    private function delete($packageName)
    {
        $this->messages->reset();
        $package = $this->autoUpdate->repository->getPackage($packageName);

        if (false === $package->deletePackage()) {
            $this->messages->add('AU_DELETE', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_DELETE', 'AU_OK');
    }

    private function upgrade($packageName)
    {
        // Remise a zéro des messages
        $this->messages->reset();

        $package = $this->autoUpdate->repository->getPackage($packageName);

        // Téléchargement de l'archive
        $file = $package->getFile();
        if (false === $file) {
            $this->messages->add('AU_DOWNLOAD', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_DOWNLOAD', 'AU_OK');

        // Vérification MD5
        if (!$package->checkIntegrity($file)) {
            $this->messages->add('AU_INTEGRITY', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_INTEGRITY', 'AU_OK');

        // Extraction de l'archive
        $path = $package->extract();
        if (false === $path) {
            $this->messages->add('AU_EXTRACT', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_EXTRACT', 'AU_OK');

        // Vérification des droits sur le fichiers
        if (!$package->checkACL()) {
            $this->messages->add('AU_ACL', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_ACL', 'AU_OK');

        // Mise à jour du paquet
        if (!$package->upgrade()) {
            $this->messages->add(
                _t('AU_UPDATE_PACKAGE') . $packageName,
                'AU_ERROR'
            );
            return;
        }
        $this->messages->add(_t('AU_UPDATE_PACKAGE') . $packageName, 'AU_OK');

        if (get_class($package) === PackageCollection::CORE_CLASS) {
            // Mise à jour des tools.
            if (!$package->upgradeTools()) {
                $this->messages->add('AU_UPDATE_TOOL', 'AU_ERROR');
                return;
            }
            $this->messages->add('AU_UPDATE_TOOL', 'AU_OK');
        }

        // Mise à jour de la configuration de YesWiki
        if (!$package->upgradeInfos()) {
            $this->messages->add('AU_UPDATE_INFOS', 'AU_ERROR');
            return;
        }
        $this->messages->add('AU_UPDATE_INFOS', 'AU_OK');

        $package->cleanTempFiles();
    }
}
