<?php
namespace YesWiki\Core;
use YesWiki\Core\YesWikiPerformable;

abstract class YesWikiAction extends YesWikiPerformable {}