# Tools directory

The folder `tools` will be used to install yeswiki extensions downloaded from the yeswiki repository.  
This is automatically installed by the action {{update}} in the administration menu.  
Some tools are installed by default, so this folder is not empty by default.  

For your custom tools, please use `custom/tools/` (otherwise there is a risk for loosing custom changes while updating your wiki). You can copy an existing theme there to modify it (priority to `custom/tools/` folder when two identicals names for extensions are used).
