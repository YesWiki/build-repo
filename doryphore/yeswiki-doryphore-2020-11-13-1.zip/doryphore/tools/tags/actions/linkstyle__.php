<?php

if (!defined("WIKINI_VERSION")) {
    die("acc&egrave;s direct interdit");
}

echo '  <link rel="stylesheet" href="'.$this->getBaseUrl().'/tools/tags/presentation/styles/tags.css" />'."\n";
