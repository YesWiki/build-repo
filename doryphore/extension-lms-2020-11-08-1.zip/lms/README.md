# yeswiki-extension-lms
Permet d'utiliser YesWiki comme une plateforme d'apprentissage (LMS : Learning Management System)
