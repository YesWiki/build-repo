<?php
$GLOBALS['translations'] = array_merge($GLOBALS['translations'], array(
    'HELLOWORLD_CONFIG' => 'Test config'
));