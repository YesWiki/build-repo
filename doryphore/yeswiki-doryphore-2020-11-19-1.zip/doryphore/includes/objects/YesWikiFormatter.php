<?php
namespace YesWiki\Core;
use YesWiki\Core\YesWikiPerformable;

abstract class YesWikiFormatter extends YesWikiPerformable {}