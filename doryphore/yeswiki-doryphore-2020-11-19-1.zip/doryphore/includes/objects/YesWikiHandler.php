<?php
namespace YesWiki\Core;
use YesWiki\Core\YesWikiPerformable;

abstract class YesWikiHandler extends YesWikiPerformable {}