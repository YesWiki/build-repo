<?php
// Vérification de sécurité
if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}
