<?php
// index.php
// Administration de l'extension : initialisations (tables, fichier de configuration) , information etc.

if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}
