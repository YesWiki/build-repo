<?php
if (!defined("TOOLS_MANAGER")) {
    die("Accès direct interdit.");
}
