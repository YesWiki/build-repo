<?php

/**
 *  Programme gerant les fiches bazar depuis une interface de type geographique.
 **/

// pour retro-compatibilité
include( __DIR__.'/bazarcarto.php');
