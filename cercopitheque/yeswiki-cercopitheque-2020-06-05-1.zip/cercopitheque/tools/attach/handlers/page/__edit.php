<?php
$this->AddJavascriptFile('tools/attach/libs/fileuploader.js');
