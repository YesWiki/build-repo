<?php
if (!defined("WIKINI_VERSION"))
{
  die ("acc&egrave;s direct interdit");
}



$GLOBALS['translations'] = array_merge($GLOBALS['translations'], array(

// Action translation
'LANG_DESTINATION_REQUIRED' => 'Missing parameter destination (destination lang)',
'LANG_FLAG_FILE_MISSING' => 'No flag for this country'


));

?>