# Fallback default yeswiki theme

This folder contains the default yeswiki theme.  
**Don't add themes here, they will be deleted in updates.**  
Use the `themes` or `custom/themes` folder in the root.  
