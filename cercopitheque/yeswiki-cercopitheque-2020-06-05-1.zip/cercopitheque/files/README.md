# Files directory

The folder `files` contains uploaded files with action {{attach}} or with bazar databases.  
The content of this folder should not be removed and is important for backup of website !  
